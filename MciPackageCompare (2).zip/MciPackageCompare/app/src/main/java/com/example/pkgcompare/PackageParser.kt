package com.example.pkgcompare

object PackageParser {
    private const val FA = "۰۱۲۳۴۵۶۷۸۹"
    private const val AR = "٠١٢٣٤٥٦٧٨٩"

    private val thousands = Regex("(\\d)[,٬،](?=\\d{3}(?!\\d))")
    private val slashDecimal = Regex("(\\d)/(\\d)")

    private val priceRe =
        Regex("(\\d+(?:\\.\\d+)?)\\s*(هزار|میلیون)?\\s*(تومان|ریال)")
    private val priceReverseRe = Regex("(تومان|ریال)\\s*(\\d+(?:\\.\\d+)?)")
    private val volRe = Regex(
        "(\\d+(?:\\.\\d+)?)\\s*(ترابایت|گیگابایت|مگابایت|کیلوبایت|گیگ|مگ|TB|GB|MB|KB)",
        RegexOption.IGNORE_CASE
    )
    private val numericDuration =
        Regex("(\\d+(?:\\.\\d+)?)\\s*(روزه|روز|ساعته|ساعت|هفته|ماهه|ماه|ساله|سال)")
    private val wordMonths =
        Regex("(یک|دو|سه|چهار|پنج|شش|هفت|نه|دوازده)\\s*(ماهه|ماه)")
    private val wordMonthValue = mapOf(
        "یک" to 1, "دو" to 2, "سه" to 3, "چهار" to 4, "پنج" to 5,
        "شش" to 6, "هفت" to 7, "نه" to 9, "دوازده" to 12
    )
    private val bonusWords = listOf("شبانه", "هدیه", "رایگان", "بونوس", "اضافه")

    fun normalize(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            val i = FA.indexOf(c)
            val j = AR.indexOf(c)
            sb.append(
                when {
                    i >= 0 -> '0' + i
                    j >= 0 -> '0' + j
                    c == '‌' -> ' '
                    c == '٫' -> '.'
                    c == 'ي' -> 'ی'
                    c == 'ك' -> 'ک'
                    else -> c
                }
            )
        }
        return sb.toString()
            .replace(thousands, "\$1")
            .replace(slashDecimal, "\$1.\$2")
    }

    /** کلید مقایسه‌ی متن (بدون فاصله) برای پیدا کردن دکمه‌ها */
    fun key(s: String): String = normalize(s).replace(" ", "")

    private fun toToman(num: String, mult: String?, unit: String): Long {
        var v = num.toDouble()
        when (mult) {
            "هزار" -> v *= 1_000
            "میلیون" -> v *= 1_000_000
        }
        if (unit == "ریال") v /= 10
        return Math.round(v)
    }

    fun prices(n: String): List<Long> {
        val out = mutableListOf<Long>()
        priceRe.findAll(n).forEach { m ->
            out += toToman(m.groupValues[1], m.groupValues[2].ifEmpty { null }, m.groupValues[3])
        }
        if (out.isEmpty()) {
            priceReverseRe.findAll(n).forEach { m ->
                out += toToman(m.groupValues[2], null, m.groupValues[1])
            }
        }
        return out.filter { it > 0 }
    }

    /** لیست (حجم به گیگابایت، آیا هدیه/شبانه است) */
    fun volumes(n: String): List<Pair<Double, Boolean>> {
        return volRe.findAll(n).map { m ->
            val v = m.groupValues[1].toDouble()
            val gb = when (m.groupValues[2].lowercase()) {
                "ترابایت", "tb" -> v * 1024
                "گیگابایت", "گیگ", "gb" -> v
                "مگابایت", "مگ", "mb" -> v / 1024
                else -> v / (1024 * 1024)
            }
            val from = maxOf(0, m.range.first - 14)
            val to = minOf(n.length, m.range.last + 15)
            val ctx = n.substring(from, to)
            gb to bonusWords.any { ctx.contains(it) }
        }.toList()
    }

    fun days(n: String): Double? {
        numericDuration.find(n)?.let { m ->
            val v = m.groupValues[1].toDouble()
            return when (m.groupValues[2]) {
                "روزه", "روز" -> v
                "ساعته", "ساعت" -> v / 24
                "هفته" -> v * 7
                "ماهه", "ماه" -> v * 30
                else -> v * 365
            }
        }
        wordMonths.find(n)?.let { m ->
            return (wordMonthValue[m.groupValues[1]] ?: return@let) * 30.0
        }
        if (Regex("یک\\s*ساله|سالانه|سالیانه").containsMatchIn(n)) return 365.0
        if (n.contains("روزانه")) return 1.0
        if (n.contains("هفتگی")) return 7.0
        if (n.contains("ماهانه")) return 30.0
        return null
    }

    fun looksLikePackage(texts: List<String>): Boolean {
        if (texts.isEmpty() || texts.size > 40) return false
        val n = normalize(texts.joinToString(" | "))
        return prices(n).isNotEmpty() && volumes(n).isNotEmpty()
    }

    fun parse(texts: List<String>): TariffPackage? {
        val n = normalize(texts.joinToString(" | "))
        val price = prices(n).minOrNull() ?: return null
        val vols = volumes(n)
        if (vols.isEmpty()) return null

        val main = vols.filter { !it.second }.map { it.first }
        val mainGb: Double
        val bonus: Double
        var night = false
        if (main.isEmpty()) {
            mainGb = vols.maxOf { it.first }
            bonus = 0.0
            night = n.contains("شبانه")
        } else {
            mainGb = main.first()
            bonus = vols.filter { it.second }.sumOf { it.first }
        }
        if (mainGb <= 0.0) return null

        val title = texts.firstOrNull { t ->
            t.any { it.isLetter() } && prices(normalize(t)).isEmpty()
        }?.trim() ?: "بسته"

        return TariffPackage(
            title = title,
            priceToman = price,
            volumeGb = mainGb,
            bonusGb = bonus,
            days = days(n),
            isNight = night,
            raw = texts.joinToString(" · ")
        )
    }
}
