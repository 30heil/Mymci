package com.example.pkgcompare

val CATEGORY_ORDER = listOf(
    "ساعتی", "روزانه", "چندروزه", "هفتگی", "ماهانه",
    "سه‌ماهه", "شش‌ماهه", "سالانه", "شبانه", "سایر"
)

data class TariffPackage(
    val title: String,
    val priceToman: Long,
    val volumeGb: Double,
    val bonusGb: Double,
    val days: Double?,
    val isNight: Boolean,
    val raw: String
) {
    /** قیمت هر گیگ (فقط حجم اصلی، بدون هدیه) */
    val pricePerGb: Double get() = priceToman / volumeGb

    /** قیمت هر گیگ با احتساب حجم هدیه */
    val pricePerGbWithBonus: Double get() = priceToman / (volumeGb + bonusGb)

    val key: String get() = "$title|$volumeGb|$bonusGb|$days|$priceToman"

    val category: String
        get() {
            if (isNight) return "شبانه"
            val d = days ?: return "سایر"
            return when {
                d < 1.0 -> "ساعتی"
                d == 1.0 -> "روزانه"
                d < 7.0 -> "چندروزه"
                d < 30.0 -> "هفتگی"
                d < 90.0 -> "ماهانه"
                d < 180.0 -> "سه‌ماهه"
                d < 365.0 -> "شش‌ماهه"
                else -> "سالانه"
            }
        }
}
