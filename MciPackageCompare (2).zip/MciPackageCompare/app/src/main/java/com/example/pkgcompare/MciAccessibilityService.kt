package com.example.pkgcompare

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MciAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: MciAccessibilityService? = null

        /** نام تب‌های احتمالی صفحه‌ی خرید بسته؛ در صورت نیاز با متن واقعی اپ تنظیم شود */
        val TAB_LABELS = listOf(
            "ساعتی", "روزانه", "هفتگی", "ماهانه", "سه ماهه", "شش ماهه",
            "نه ماهه", "سالانه", "شبانه", "ویژه", "پرحجم"
        )
        val NAV_LABELS = listOf("خرید بسته جدید", "خرید بسته", "بسته‌ها", "بسته ها")
    }

    private val handler = Handler(Looper.getMainLooper())
    private val visited = mutableSetOf<String>()
    private var idle = 0
    private var navTries = 0
    private var ticks = 0

    override fun onServiceConnected() {
        instance = this
        ScanState.connected.value = true
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        ScanState.connected.value = false
        stopScan()
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun startScan() {
        visited.clear()
        idle = 0
        navTries = 0
        ticks = 0
        ScanState.scanning.value = true
        ScanState.status.value = "در حال اسکن…"
        handler.removeCallbacks(tick)
        handler.postDelayed(tick, 1500)
    }

    fun stopScan(msg: String? = null) {
        ScanState.scanning.value = false
        handler.removeCallbacks(tick)
        if (msg != null) ScanState.status.value = msg
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!ScanState.scanning.value) return
            try {
                step()
            } catch (e: Exception) {
                ScanState.status.value = "خطا: ${e.message}"
            }
            if (ScanState.scanning.value) handler.postDelayed(this, 1500)
        }
    }

    private fun step() {
        if (++ticks > 400) {
            stopScan("اسکن بیش از حد طول کشید و متوقف شد")
            return
        }
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (pkg == packageName || !pkg.contains("mci", ignoreCase = true)) {
            ScanState.status.value = "اپ MyMCI را باز کنید…"
            return
        }

        val dumpList = mutableListOf<String>()
        collectTexts(root, dumpList)
        ScanState.lastDump = dumpList.joinToString("\n")

        val found = extractCards(root).mapNotNull { PackageParser.parse(it) }
        if (found.isEmpty()) {
            if (navTries++ > 12) {
                stopScan("صفحه‌ی بسته‌ها پیدا نشد. دستی وارد «خرید بسته جدید» شوید و دوباره شروع کنید.")
                return
            }
            ScanState.status.value = "در حال رفتن به صفحه‌ی خرید بسته…"
            clickByContains(root, NAV_LABELS)
            return
        }
        navTries = 0

        val added = ScanState.add(found)
        ScanState.status.value = "${ScanState.packages.value.size} بسته پیدا شد…"
        if (added > 0) {
            idle = 0
            scrollForward(root)
            return
        }
        idle++
        val scrolled = if (idle < 2) scrollForward(root) else false
        if (scrolled) return
        if (clickNextTab(root)) {
            idle = 0
        } else {
            stopScan("اسکن کامل شد: ${ScanState.packages.value.size} بسته")
        }
    }

    // ---------- استخراج کارت‌ها ----------

    /** کوچک‌ترین ظرفی که هم قیمت و هم حجم دارد یک «کارت بسته» حساب می‌شود */
    private fun extractCards(node: AccessibilityNodeInfo): List<List<String>> {
        if (!node.isVisibleToUser) return emptyList()
        val cards = mutableListOf<List<String>>()
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            cards += extractCards(c)
        }
        if (cards.isNotEmpty()) return cards
        val texts = mutableListOf<String>()
        collectTexts(node, texts)
        return if (PackageParser.looksLikePackage(texts)) listOf(texts) else emptyList()
    }

    private fun collectTexts(node: AccessibilityNodeInfo, out: MutableList<String>) {
        if (!node.isVisibleToUser) return
        val t = node.text?.toString()?.takeIf { it.isNotBlank() }
            ?: node.contentDescription?.toString()?.takeIf { it.isNotBlank() }
        if (t != null) out += t.trim()
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            collectTexts(c, out)
        }
    }

    // ---------- کلیک و اسکرول ----------

    private fun findNode(
        node: AccessibilityNodeInfo,
        pred: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (pred(node)) return node
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            findNode(c, pred)?.let { return it }
        }
        return null
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        while (cur != null) {
            if (cur.isClickable) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
        }
        return false
    }

    private fun nodeKey(n: AccessibilityNodeInfo): String =
        PackageParser.key(n.text?.toString() ?: n.contentDescription?.toString() ?: "")

    private fun clickByContains(root: AccessibilityNodeInfo, labels: List<String>): Boolean {
        for (label in labels) {
            val k = PackageParser.key(label)
            val node = findNode(root) { it.isVisibleToUser && nodeKey(it).contains(k) && k.isNotEmpty() }
                ?: continue
            if (clickNode(node)) return true
        }
        return false
    }

    private fun clickNextTab(root: AccessibilityNodeInfo): Boolean {
        for (label in TAB_LABELS) {
            if (label in visited) continue
            val k = PackageParser.key(label)
            val node = findNode(root) { it.isVisibleToUser && nodeKey(it) == k } ?: continue
            visited += label
            if (clickNode(node)) return true
        }
        return false
    }

    private fun scrollForward(root: AccessibilityNodeInfo): Boolean {
        val scrollables = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo) {
            if (n.isScrollable && n.isVisibleToUser) scrollables += n
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        // لیست عمودی اصلی = بلندترین ناحیه‌ی اسکرول‌شدنی
        val target = scrollables.maxByOrNull {
            val r = Rect()
            it.getBoundsInScreen(r)
            r.height()
        } ?: return false
        return target.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }
}
