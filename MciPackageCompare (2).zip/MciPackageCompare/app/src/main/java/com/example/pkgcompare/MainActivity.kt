package com.example.pkgcompare

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.CompositionLocalProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(Modifier.fillMaxSize()) { Screen() }
                }
            }
        }
    }
}

// ---------- ابزارهای نمایش ----------

private fun fa(s: String): String = s.map { c -> if (c in '0'..'9') "۰۱۲۳۴۵۶۷۸۹"[c - '0'] else c }
    .joinToString("")

private fun fa(n: Int): String = fa(n.toString())

private fun money(v: Long): String =
    fa(String.format(Locale.US, "%,d", v).replace(',', '٬'))

private fun gb(v: Double): String =
    fa(if (v == Math.floor(v)) v.toLong().toString() else String.format(Locale.US, "%.1f", v))

private fun dur(days: Double): String = when {
    days < 1.0 -> "${fa((days * 24).roundToInt())} ساعت"
    days >= 365.0 && days % 365.0 == 0.0 -> "${fa((days / 365).roundToInt())} سال"
    days >= 30.0 && days % 30.0 == 0.0 -> "${fa((days / 30).roundToInt())} ماه"
    else -> "${fa(days.roundToInt())} روز"
}

private fun launchMci(ctx: Context): Boolean {
    val pm = ctx.packageManager
    val probe = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val match = pm.queryIntentActivities(probe, 0).firstOrNull { ri ->
        val p = ri.activityInfo.packageName
        if (p == ctx.packageName) return@firstOrNull false
        val label = ri.loadLabel(pm).toString()
        p.contains("mci", true) || label.contains("MyMCI", true) || label.contains("همراه من")
    } ?: return false
    val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
    ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    return true
}

// ---------- صفحه‌ی اصلی ----------

@Composable
fun Screen() {
    val ctx = LocalContext.current
    val pkgs by ScanState.packages.collectAsStateWithLifecycle()
    val scanning by ScanState.scanning.collectAsStateWithLifecycle()
    val connected by ScanState.connected.collectAsStateWithLifecycle()
    val status by ScanState.status.collectAsStateWithLifecycle()
    var grouped by remember { mutableStateOf(true) }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text(
            "مقایسه‌ی بسته‌های اینترنت MyMCI",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))

        if (!connected) {
            Text("برای خواندن صفحه‌ی بسته‌ها، سرویس دسترسی‌پذیری «مقایسه بسته MCI» را فعال کنید.")
            Spacer(Modifier.height(6.dp))
            Button(onClick = {
                ctx.startActivity(
                    Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }) { Text("فعال‌سازی سرویس") }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!scanning) {
                    Button(onClick = {
                        if (!launchMci(ctx)) {
                            Toast.makeText(ctx, "اپ MyMCI پیدا نشد؛ آن را دستی باز کنید", Toast.LENGTH_LONG).show()
                        }
                        MciAccessibilityService.instance?.startScan()
                    }) { Text("شروع اسکن") }
                } else {
                    Button(onClick = { MciAccessibilityService.instance?.stopScan("متوقف شد") }) {
                        Text("توقف")
                    }
                }
                OutlinedButton(onClick = { ScanState.clear() }) { Text("پاک کردن") }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(status, style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("dump", ScanState.lastDump))
            Toast.makeText(ctx, "متن آخرین صفحه کپی شد", Toast.LENGTH_SHORT).show()
        }) { Text("کپی متن صفحه (برای عیب‌یابی)") }

        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = grouped, onClick = { grouped = true }, label = { Text("دسته‌بندی") })
            FilterChip(selected = !grouped, onClick = { grouped = false }, label = { Text("رتبه‌بندی کلی") })
        }
        Spacer(Modifier.height(6.dp))

        if (pkgs.isEmpty()) {
            Text("هنوز بسته‌ای ثبت نشده است.", style = MaterialTheme.typography.bodyMedium)
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (grouped) {
                val groups = pkgs.groupBy { it.category }.toList().sortedBy { (cat, _) ->
                    CATEGORY_ORDER.indexOf(cat).let { if (it < 0) 99 else it }
                }
                groups.forEach { (cat, list) ->
                    val sorted = list.sortedBy { it.pricePerGb }
                    item(key = "header-$cat") {
                        Text(
                            "$cat (${fa(sorted.size)} بسته)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                    itemsIndexed(sorted, key = { _, p -> "$cat-${p.key}" }) { i, p ->
                        PackageCard(p, i + 1, sorted.first().pricePerGb)
                    }
                }
            } else {
                val sorted = pkgs.sortedBy { it.pricePerGb }
                itemsIndexed(sorted, key = { _, p -> p.key }) { i, p ->
                    PackageCard(p, i + 1, sorted.first().pricePerGb, showCategory = true)
                }
            }
        }
    }
}

@Composable
fun PackageCard(p: TariffPackage, rank: Int, best: Double, showCategory: Boolean = false) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "${fa(rank)}. ${p.title}",
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                if (rank == 1) {
                    AssistChip(onClick = {}, label = { Text("به‌صرفه‌ترین") })
                }
            }
            val volume = buildString {
                append("حجم: ${gb(p.volumeGb)} گیگ")
                if (p.bonusGb > 0) append(" + ${gb(p.bonusGb)} گیگ هدیه")
                p.days?.let { append(" · مدت: ${dur(it)}") }
                if (showCategory) append(" · ${p.category}")
            }
            Text(volume, style = MaterialTheme.typography.bodyMedium)
            Text("قیمت: ${money(p.priceToman)} تومان", style = MaterialTheme.typography.bodyMedium)
            Text(
                "هر گیگ: ${money(p.pricePerGb.toLong())} تومان",
                fontWeight = FontWeight.Bold
            )
            if (p.bonusGb > 0) {
                Text(
                    "هر گیگ با احتساب هدیه: ${money(p.pricePerGbWithBonus.toLong())} تومان",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            if (rank > 1 && best > 0) {
                val extra = ((p.pricePerGb / best - 1) * 100).roundToInt()
                if (extra > 0) {
                    Text(
                        "${fa(extra)}٪ گران‌تر از بهترین گزینه",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}
