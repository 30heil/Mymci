package com.example.pkgcompare

object PackageParser {
    private const val FA = "۰۱۲۳۴۵۶۷۸۹"
    private const val AR = "٠١٢٣٤٥٦٧٨٩"

    private val thousands = Regex("(\\d)[,٬،](?=\\d{3}(?!\\d))")
    private val dotThousands = Regex("(?<![\\d.])\\d{1,3}(?:\\.\\d{3}){2,}(?![\\d.])")
    private val slashDecimal = Regex("(\\d)/(\\d)")

    // قیمت: «۱۴,۹۰۰,۰۰۰ ریال» (عدد و واحد ممکن است در دو نود جدا باشند)
    private val priceRe =
        Regex("(\\d+(?:\\.\\d+)?)[\\s|]*(هزار|میلیون)?[\\s|]*(تومان|ریال)")
    private val priceReverseRe = Regex("(تومان|ریال)[\\s|]*(\\d+(?:\\.\\d+)?)")
    private val priceOnlyRe = Regex(
        "^\\s*(?:\\d+(?:\\.\\d+)?\\s*(?:هزار|میلیون)?\\s*(?:تومان|ریال)" +
            "|(?:تومان|ریال)\\s*\\d+(?:\\.\\d+)?|تومان|ریال)\\s*$"
    )

    private val volRe = Regex(
        "(\\d+(?:\\.\\d+)?)\\s*(ترابایت|گیگابایت|مگابایت|کیلوبایت|گیگ|مگ|TB|GB|MB|KB)",
        RegexOption.IGNORE_CASE
    )
    private val numericDuration =
        Regex("(\\d+(?:\\.\\d+)?)\\s*(روزه|روز|ساعته|ساعت|هفته|ماهه|ماه|ساله|سال)")

    private val wordNums = mapOf(
        "یک" to 1, "دو" to 2, "سه" to 3, "چهار" to 4, "پنج" to 5, "شش" to 6,
        "هفت" to 7, "هشت" to 8, "نه" to 9, "ده" to 10, "یازده" to 11,
        "دوازده" to 12, "پانزده" to 15, "بیست" to 20, "سی" to 30,
        "چهل" to 40, "پنجاه" to 50, "شصت" to 60, "نود" to 90
    )
    private val wordAlt = wordNums.keys.sortedByDescending { it.length }.joinToString("|")
    private val wordDuration =
        Regex("(?<![\\u0600-\\u06FF])($wordAlt)\\s*(روزه|روز|ماهه|ماه)")

    private val bonusWords = listOf("شبانه", "هدیه", "رایگان", "بونوس", "اضافه")

    fun normalize(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            val i = FA.indexOf(c)
            val j = AR.indexOf(c)
            sb.append(
                when {
                    i >= 0 -> '0' + i
                    j >= 0 -> '0' + j
                    c == '‌' -> ' '
                    c == '٫' -> '.'
                    c == 'ي' -> 'ی'
                    c == 'ك' -> 'ک'
                    else -> c
                }
            )
        }
        var out = sb.toString().replace(thousands, "\$1")
        out = dotThousands.replace(out) { it.value.replace(".", "") }
        return out.replace(slashDecimal, "\$1.\$2")
    }

    /** کلید مقایسه‌ی متن (بدون فاصله) برای پیدا کردن دکمه‌ها */
    fun key(s: String): String = normalize(s).replace(" ", "").trim()

    private val noiseKeys = listOf(
        "پرداخت مستقیم", "پرداخت", "خرید", "جزئیات", "مشاهده جزئیات", "فعالسازی"
    ).map { key(it) }.toSet()

    private fun isNoise(t: String) = key(t) in noiseKeys
    private fun isPriceOnly(t: String) = priceOnlyRe.matches(normalize(t).trim())

    /** تیتر بسته: متن بلند حرف‌دار که قیمت و دکمه نیست */
    private fun isTitleLike(t: String): Boolean {
        val n = normalize(t).trim()
        return n.any { it.isLetter() } && n.length >= 12 && !isNoise(t) && !isPriceOnly(t)
    }

    /** برچسب کوتاه مثل «ماهانه» یا «بلند مدت» */
    private fun isChip(t: String): Boolean {
        val n = normalize(t).trim()
        return n.any { it.isLetter() } && n.length in 3..14 && !isNoise(t) && !isPriceOnly(t)
    }

    private fun toRial(num: String, mult: String?, unit: String): Long {
        var v = num.toDouble()
        when (mult) {
            "هزار" -> v *= 1_000
            "میلیون" -> v *= 1_000_000
        }
        if (unit == "تومان") v *= 10
        return Math.round(v)
    }

    /** همه‌ی قیمت‌های داخل متن، به ریال */
    fun prices(n: String): List<Long> {
        val out = mutableListOf<Long>()
        priceRe.findAll(n).forEach { m ->
            out += toRial(m.groupValues[1], m.groupValues[2].ifEmpty { null }, m.groupValues[3])
        }
        if (out.isEmpty()) {
            priceReverseRe.findAll(n).forEach { m ->
                out += toRial(m.groupValues[2], null, m.groupValues[1])
            }
        }
        return out.filter { it > 0 }
    }

    /** لیست (حجم به گیگابایت، آیا هدیه/شبانه است) برای یک متن */
    fun volumes(n: String): List<Pair<Double, Boolean>> {
        return volRe.findAll(n).map { m ->
            val v = m.groupValues[1].toDouble()
            val gb = when (m.groupValues[2].lowercase()) {
                "ترابایت", "tb" -> v * 1024
                "گیگابایت", "گیگ", "gb" -> v
                "مگابایت", "مگ", "mb" -> v / 1024
                else -> v / (1024 * 1024)
            }
            val from = maxOf(0, m.range.first - 14)
            val to = minOf(n.length, m.range.last + 15)
            val ctx = n.substring(from, to)
            gb to bonusWords.any { ctx.contains(it) }
        }.toList()
    }

    fun days(n: String): Double? {
        numericDuration.find(n)?.let { m ->
            val v = m.groupValues[1].toDouble()
            return when (m.groupValues[2]) {
                "روزه", "روز" -> v
                "ساعته", "ساعت" -> v / 24
                "هفته" -> v * 7
                "ماهه", "ماه" -> v * 30
                else -> v * 365
            }
        }
        wordDuration.find(n)?.let { m ->
            val v = wordNums[m.groupValues[1]] ?: return@let
            return if (m.groupValues[2].startsWith("ماه")) v * 30.0 else v.toDouble()
        }
        if (Regex("یک\\s*ساله|سالانه|سالیانه").containsMatchIn(n)) return 365.0
        if (n.contains("روزانه")) return 1.0
        if (n.contains("هفتگی")) return 7.0
        if (n.contains("ماهانه")) return 30.0
        return null
    }

    /** یک ظرف وقتی «کارت بسته» است که قیمت و یک تیتر بلند داشته باشد */
    fun looksLikePackage(texts: List<String>): Boolean {
        if (texts.size < 2 || texts.size > 40) return false
        val joined = normalize(texts.joinToString(" | "))
        return prices(joined).isNotEmpty() && texts.any { isTitleLike(it) }
    }

    fun parse(texts: List<String>, section: String): TariffPackage? {
        val norm = texts.map { normalize(it) }
        val joined = norm.joinToString(" | ")
        val price = prices(joined).minOrNull() ?: return null

        val vols = norm.flatMap { volumes(it) }
        val main = vols.filter { !it.second }.map { it.first }
        val volume: Double? = when {
            main.isNotEmpty() -> main.first()
            vols.isNotEmpty() -> vols.maxOf { it.first }
            else -> null
        }
        val bonus = if (main.isNotEmpty()) vols.filter { it.second }.sumOf { it.first } else 0.0

        val titleIdx = texts.indexOfFirst { isTitleLike(it) }
        val title = if (titleIdx >= 0) texts[titleIdx].trim() else "بسته"
        val tag = texts.withIndex()
            .firstOrNull { (i, t) -> i != titleIdx && isChip(t) }?.value?.trim()

        return TariffPackage(
            section = section,
            title = title,
            tag = tag,
            priceRial = price,
            volumeGb = volume?.takeIf { it > 0 },
            bonusGb = bonus,
            days = days(joined),
            unlimited = joined.contains("نامحدود"),
            raw = texts.joinToString(" · ")
        )
    }
}
