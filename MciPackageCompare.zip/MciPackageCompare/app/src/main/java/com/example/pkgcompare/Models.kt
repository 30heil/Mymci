package com.example.pkgcompare

/** ترتیب بخش‌هایی که اپ به ترتیب وارد آن‌ها می‌شود */
val SECTIONS = listOf("اینترنت", "همراهی", "پیشنهادی", "ویژه مودم")

val CATEGORY_ORDER = listOf(
    "ساعتی", "روزانه", "چندروزه", "هفتگی", "ماهانه",
    "سه‌ماهه", "شش‌ماهه", "سالانه", "سایر"
)

data class TariffPackage(
    val section: String,
    val title: String,
    /** برچسب خود اپ، مثل «ماهانه» یا «بلند مدت» */
    val tag: String?,
    /** قیمت دقیقاً به ریال، همان‌طور که در MyMCI نوشته شده */
    val priceRial: Long,
    val volumeGb: Double?,
    val bonusGb: Double,
    val days: Double?,
    val unlimited: Boolean,
    val raw: String
) {
    /** قیمت هر گیگ به ریال (فقط حجم اصلی) */
    val pricePerGb: Double?
        get() = volumeGb?.takeIf { it > 0 }?.let { priceRial / it }

    /** قیمت هر گیگ به ریال با احتساب حجم هدیه */
    val pricePerGbWithBonus: Double?
        get() = volumeGb?.takeIf { it > 0 }?.let { priceRial / (it + bonusGb) }

    val key: String get() = "$section|$title|$volumeGb|$bonusGb|$days|$priceRial"

    val category: String
        get() {
            val d = days ?: return "سایر"
            return when {
                d < 1.0 -> "ساعتی"
                d == 1.0 -> "روزانه"
                d < 7.0 -> "چندروزه"
                d < 30.0 -> "هفتگی"
                d < 90.0 -> "ماهانه"
                d < 180.0 -> "سه‌ماهه"
                d < 365.0 -> "شش‌ماهه"
                else -> "سالانه"
            }
        }
}
