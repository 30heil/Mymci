package com.example.pkgcompare

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MciAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: MciAccessibilityService? = null

        const val HUB_LABEL = "خرید بسته جدید"
        const val PACKAGES_TAB = "بسته‌ها"
    }

    /**
     * TO_HUB : رفتن به صفحه‌ی «خرید بسته جدید»
     * ENTER  : کلیک روی کاشی بخش فعلی (اینترنت، همراهی، ...)
     * SCAN   : خواندن کارت‌ها و اسکرول تا انتهای لیست
     * BACK   : برگشت به صفحه‌ی «خرید بسته جدید»
     */
    private enum class Phase { TO_HUB, ENTER, SCAN, BACK }

    private val handler = Handler(Looper.getMainLooper())
    private var phase = Phase.TO_HUB
    private var sectionIdx = 0
    private var idle = 0
    private var navTries = 0
    private var waitTicks = 0
    private var backTries = 0
    private var ticks = 0

    override fun onServiceConnected() {
        instance = this
        ScanState.connected.value = true
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        ScanState.connected.value = false
        stopScan()
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun startScan() {
        phase = Phase.TO_HUB
        sectionIdx = 0
        idle = 0
        navTries = 0
        waitTicks = 0
        backTries = 0
        ticks = 0
        ScanState.scanning.value = true
        ScanState.status.value = "در حال اسکن…"
        handler.removeCallbacks(tick)
        handler.postDelayed(tick, 2000)
    }

    fun stopScan(msg: String? = null) {
        ScanState.scanning.value = false
        handler.removeCallbacks(tick)
        if (msg != null) ScanState.status.value = msg
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!ScanState.scanning.value) return
            try {
                step()
            } catch (e: Exception) {
                ScanState.status.value = "خطا: ${e.message}"
            }
            if (ScanState.scanning.value) handler.postDelayed(this, 1500)
        }
    }

    private fun step() {
        if (++ticks > 600) {
            stopScan("اسکن بیش از حد طول کشید و متوقف شد")
            return
        }
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (pkg == packageName || !pkg.contains("mci", ignoreCase = true)) {
            ScanState.status.value = "اپ MyMCI را باز کنید…"
            return
        }

        val texts = mutableListOf<String>()
        collectTexts(root, texts)
        ScanState.lastDump = texts.joinToString("\n")

        // صفحه‌ی «خرید بسته جدید» = همه‌ی کاشی‌های چهار بخش دیده می‌شوند
        val keys = texts.map { PackageParser.key(it) }.toSet()
        val onHub = SECTIONS.all { PackageParser.key(it) in keys }

        when (phase) {
            Phase.TO_HUB -> toHub(root, onHub)
            Phase.ENTER -> enter(root, onHub)
            Phase.SCAN -> scan(root, onHub)
            Phase.BACK -> back(onHub)
        }
    }

    // ---------- مراحل ----------

    private fun toHub(root: AccessibilityNodeInfo, onHub: Boolean) {
        if (onHub) {
            phase = Phase.ENTER
            waitTicks = 0
            navTries = 0
            return
        }
        if (navTries++ > 14) {
            stopScan("به صفحه‌ی «خرید بسته جدید» نرسید. دستی وارد آن شوید و دوباره شروع کنید.")
            return
        }
        ScanState.status.value = "در حال رفتن به «خرید بسته جدید»…"
        val hubKey = PackageParser.key(HUB_LABEL)
        val hubBtn = findNode(root) { it.isVisibleToUser && nodeKey(it).contains(hubKey) }
        if (hubBtn != null && clickNode(hubBtn)) return
        val tabKey = PackageParser.key(PACKAGES_TAB)
        val tab = findNode(root) { it.isVisibleToUser && nodeKey(it) == tabKey }
        if (tab != null && clickNode(tab)) return
        if (navTries > 4) performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun enter(root: AccessibilityNodeInfo, onHub: Boolean) {
        if (!onHub) {
            if (waitTicks++ > 3) phase = Phase.TO_HUB
            return
        }
        waitTicks = 0
        val label = SECTIONS[sectionIdx]
        val k = PackageParser.key(label)
        val tile = findNode(root) { it.isVisibleToUser && nodeKey(it) == k }
        if (tile == null || !clickNode(tile)) {
            ScanState.status.value = "بخش «$label» پیدا نشد"
            sectionIdx++
            if (sectionIdx >= SECTIONS.size) finishAll()
            return
        }
        ScanState.status.value = "در حال خواندن بخش «$label»…"
        phase = Phase.SCAN
        idle = 0
        waitTicks = 0
    }

    private fun scan(root: AccessibilityNodeInfo, onHub: Boolean) {
        if (onHub) { // کلیک انجام نشده یا برگشته‌ایم
            phase = Phase.ENTER
            waitTicks = 0
            return
        }
        val section = SECTIONS[sectionIdx]
        val found = extractCards(root).mapNotNull { PackageParser.parse(it, section) }
        if (found.isEmpty()) {
            waitTicks++
            if (waitTicks >= 2) scrollForward(root)
            if (waitTicks >= 5) finishSection()
            return
        }
        waitTicks = 0
        val added = ScanState.add(found)
        val count = ScanState.packages.value.count { it.section == section }
        ScanState.status.value = "«$section»: $count بسته پیدا شد…"
        if (added > 0) {
            idle = 0
            scrollForward(root)
            return
        }
        idle++
        if (idle < 2 && scrollForward(root)) return
        finishSection()
    }

    private fun back(onHub: Boolean) {
        if (onHub) {
            phase = Phase.ENTER
            waitTicks = 0
            return
        }
        if (++backTries > 4) {
            phase = Phase.TO_HUB
            navTries = 0
            return
        }
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun finishSection() {
        sectionIdx++
        if (sectionIdx >= SECTIONS.size) {
            finishAll()
        } else {
            phase = Phase.BACK
            backTries = 0
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    private fun finishAll() {
        stopScan("اسکن کامل شد: ${ScanState.packages.value.size} بسته")
    }

    // ---------- استخراج کارت‌ها ----------

    private class TNode(val text: String, val r: Rect) {
        var isTitle = false
    }

    private fun collectTNodes(node: AccessibilityNodeInfo, out: MutableList<TNode>) {
        if (!node.isVisibleToUser) return
        val t = node.text?.toString()?.takeIf { it.isNotBlank() }
            ?: node.contentDescription?.toString()?.takeIf { it.isNotBlank() }
        if (t != null && t.length < 400) {
            val r = Rect()
            node.getBoundsInScreen(r)
            out += TNode(t.trim(), r)
        }
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            collectTNodes(c, out)
        }
    }

    /**
     * کارت‌ها بر اساس موقعیت روی صفحه جدا می‌شوند: هر متن بلند (تیتر بسته) شروع یک کارت است
     * و قیمت، برچسب و دکمه‌های زیر آن (تا تیتر بعدی) به همان کارت تعلق دارند.
     * این روش به ساختار درختی اپ وابسته نیست و قیمت یک بسته با تیتر بسته‌ی دیگر ترکیب نمی‌شود.
     */
    private fun extractCards(root: AccessibilityNodeInfo): List<List<String>> {
        val listNode = largestScrollable(root) ?: root
        val nodes = mutableListOf<TNode>()
        collectTNodes(listNode, nodes)
        nodes.forEach { it.isTitle = PackageParser.isTitleLike(it.text) }
        val titles = nodes.filter { it.isTitle }
        if (titles.isEmpty()) return emptyList()

        val groups = LinkedHashMap<TNode, MutableList<TNode>>()
        titles.forEach { groups[it] = mutableListOf() }
        for (n in nodes) {
            if (n.isTitle) continue
            val owner = titles
                .filter { it.r.top <= n.r.top + 8 }
                .maxWithOrNull(
                    compareBy<TNode>(
                        { it.r.top },
                        { -Math.abs(it.r.centerX() - n.r.centerX()) }
                    )
                ) ?: continue
            groups[owner]?.add(n)
        }
        return groups.map { (t, rest) ->
            listOf(t.text) + rest.sortedBy { it.r.top }.map { it.text }
        }.filter { PackageParser.hasPrice(it) }
    }

    private fun largestScrollable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val scrollables = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo) {
            if (n.isScrollable && n.isVisibleToUser) scrollables += n
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        // لیست عمودی اصلی = بلندترین ناحیه‌ی اسکرول‌شدنی
        return scrollables.maxByOrNull {
            val r = Rect()
            it.getBoundsInScreen(r)
            r.height()
        }
    }

    private fun collectTexts(node: AccessibilityNodeInfo, out: MutableList<String>) {
        if (!node.isVisibleToUser) return
        val t = node.text?.toString()?.takeIf { it.isNotBlank() }
            ?: node.contentDescription?.toString()?.takeIf { it.isNotBlank() }
        if (t != null) out += t.trim()
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            collectTexts(c, out)
        }
    }

    // ---------- کلیک و اسکرول ----------

    private fun nodeKey(n: AccessibilityNodeInfo): String =
        PackageParser.key(n.text?.toString() ?: n.contentDescription?.toString() ?: "")

    private fun findNode(
        node: AccessibilityNodeInfo,
        pred: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (pred(node)) return node
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            findNode(c, pred)?.let { return it }
        }
        return null
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        while (cur != null) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
        }
        return tap(n)
    }

    /** اگر کلیک معمولی کار نکرد، با یک تپ روی مرکز نود */
    private fun tap(n: AccessibilityNodeInfo): Boolean {
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    /**
     * حدود نصف ارتفاع لیست اسکرول می‌کند تا هیچ کارتی بین دو صفحه گم نشود
     * (اسکرول کامل ممکن است کارت بلند را از وسط ببرد و عنوان و قیمتش در دو صفحه‌ی جدا بیفتد).
     */
    private fun scrollForward(root: AccessibilityNodeInfo): Boolean {
        val list = largestScrollable(root) ?: return false
        return swipeUp(list) || list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    private fun swipeUp(list: AccessibilityNodeInfo): Boolean {
        val r = Rect()
        list.getBoundsInScreen(r)
        if (r.height() < 200) return false
        val x = r.exactCenterX()
        val path = Path().apply {
            moveTo(x, r.top + r.height() * 0.75f)
            lineTo(x, r.top + r.height() * 0.25f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 600))
            .build()
        return dispatchGesture(gesture, null, null)
    }
}
