package com.example.pkgcompare

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(Modifier.fillMaxSize()) { Screen() }
                }
            }
        }
    }
}

// ---------- ابزارهای نمایش ----------

private fun fa(s: String): String =
    s.map { c -> if (c in '0'..'9') "۰۱۲۳۴۵۶۷۸۹"[c - '0'] else c }.joinToString("")

private fun fa(n: Int): String = fa(n.toString())

private fun money(v: Long): String =
    fa(String.format(Locale.US, "%,d", v).replace(',', '٬'))

private fun gb(v: Double): String =
    fa(if (v == Math.floor(v)) v.toLong().toString() else String.format(Locale.US, "%.1f", v))

private fun dur(days: Double): String = when {
    days < 1.0 -> "${fa((days * 24).roundToInt())} ساعت"
    days >= 365.0 && days % 365.0 == 0.0 -> "${fa((days / 365).roundToInt())} سال"
    days >= 30.0 && days % 30.0 == 0.0 -> "${fa((days / 30).roundToInt())} ماه"
    else -> "${fa(days.roundToInt())} روز"
}

private fun launchMci(ctx: Context): Boolean {
    val pm = ctx.packageManager
    val probe = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val match = pm.queryIntentActivities(probe, 0).firstOrNull { ri ->
        val p = ri.activityInfo.packageName
        if (p == ctx.packageName) return@firstOrNull false
        val label = ri.loadLabel(pm).toString()
        p.contains("mci", true) || label.contains("MyMCI", true) || label.contains("همراه من")
    } ?: return false
    val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
    ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    return true
}

private val byGbThenPrice = compareBy<TariffPackage>({ it.pricePerGb ?: Double.MAX_VALUE }, { it.priceRial })

// ---------- صفحه‌ی اصلی ----------

@Composable
fun Screen() {
    val ctx = LocalContext.current
    val pkgs by ScanState.packages.collectAsStateWithLifecycle()
    val scanning by ScanState.scanning.collectAsStateWithLifecycle()
    val connected by ScanState.connected.collectAsStateWithLifecycle()
    val status by ScanState.status.collectAsStateWithLifecycle()
    // ۰ = بخش‌ها، ۱ = مدت‌زمان، ۲ = رتبه‌بندی کلی
    var mode by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text(
            "مقایسه‌ی بسته‌های اینترنت MyMCI",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))

        if (!connected) {
            Text("برای خواندن صفحه‌ی بسته‌ها، سرویس دسترسی‌پذیری «مقایسه بسته MCI» را فعال کنید.")
            Spacer(Modifier.height(6.dp))
            Button(onClick = {
                ctx.startActivity(
                    Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }) { Text("فعال‌سازی سرویس") }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!scanning) {
                    Button(onClick = {
                        if (!launchMci(ctx)) {
                            Toast.makeText(ctx, "اپ MyMCI پیدا نشد؛ آن را دستی باز کنید", Toast.LENGTH_LONG).show()
                        }
                        ScanState.clear()
                        MciAccessibilityService.instance?.startScan()
                    }) { Text("شروع اسکن") }
                } else {
                    Button(onClick = { MciAccessibilityService.instance?.stopScan("متوقف شد") }) {
                        Text("توقف")
                    }
                }
                OutlinedButton(onClick = { ScanState.clear() }) { Text("پاک کردن") }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(status, style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("dump", ScanState.lastDump))
            Toast.makeText(ctx, "متن آخرین صفحه کپی شد", Toast.LENGTH_SHORT).show()
        }) { Text("کپی متن صفحه (برای عیب‌یابی)") }

        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == 0, onClick = { mode = 0 }, label = { Text("بخش‌ها") })
            FilterChip(selected = mode == 1, onClick = { mode = 1 }, label = { Text("مدت‌زمان") })
            FilterChip(selected = mode == 2, onClick = { mode = 2 }, label = { Text("رتبه‌بندی کلی") })
        }
        Spacer(Modifier.height(6.dp))

        if (pkgs.isEmpty()) {
            Text("هنوز بسته‌ای ثبت نشده است.", style = MaterialTheme.typography.bodyMedium)
        }

        val groups: List<Pair<String, List<TariffPackage>>> = when (mode) {
            0 -> SECTIONS.mapNotNull { s ->
                pkgs.filter { it.section == s }.takeIf { it.isNotEmpty() }?.let { s to it }
            }
            1 -> pkgs.groupBy { it.category }.toList().sortedBy { (cat, _) ->
                CATEGORY_ORDER.indexOf(cat).let { if (it < 0) 99 else it }
            }
            else -> listOf("همه‌ی بسته‌ها" to pkgs)
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            groups.forEach { (name, list) ->
                val sorted = list.sortedWith(byGbThenPrice)
                val best = sorted.firstNotNullOfOrNull { it.pricePerGb }
                item(key = "header-$name") {
                    Text(
                        "$name (${fa(sorted.size)} بسته)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                itemsIndexed(sorted, key = { _, p -> p.key }) { i, p ->
                    PackageCard(p, i + 1, best, showSection = mode != 0)
                }
            }
        }
    }
}

@Composable
fun PackageCard(p: TariffPackage, rank: Int, best: Double?, showSection: Boolean) {
    val perGb = p.pricePerGb
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "${fa(rank)}. ${p.title}",
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                if (perGb != null && best != null && perGb == best) {
                    AssistChip(onClick = {}, label = { Text("به‌صرفه‌ترین") })
                }
            }
            val meta = buildList {
                if (showSection) add(p.section)
                p.tag?.let { add(it) }
                add(p.category)
            }.joinToString(" · ")
            Text(meta, style = MaterialTheme.typography.bodySmall)

            Text(
                "قیمت: ${money(p.priceRial)} ریال",
                fontWeight = FontWeight.Bold
            )
            val volume = p.volumeGb?.let { v ->
                buildString {
                    append("${gb(v)} گیگ")
                    if (p.bonusGb > 0) append(" + ${gb(p.bonusGb)} گیگ هدیه")
                }
            } ?: "نامشخص"
            Text("حجم: $volume", style = MaterialTheme.typography.bodyMedium)
            Text(
                "مدت: ${p.days?.let { dur(it) } ?: "نامشخص"}",
                style = MaterialTheme.typography.bodyMedium
            )
            if (perGb != null) {
                Text(
                    "هر گیگ: ${money(perGb.toLong())} ریال",
                    fontWeight = FontWeight.Bold
                )
                p.pricePerGbWithBonus?.let {
                    if (p.bonusGb > 0) {
                        Text(
                            "هر گیگ با احتساب هدیه: ${money(it.toLong())} ریال",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
                if (best != null && perGb > best) {
                    val extra = ((perGb / best - 1) * 100).roundToInt()
                    if (extra > 0) {
                        Text(
                            "${fa(extra)}٪ گران‌تر از بهترین گزینه",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            } else {
                Text("حجم مشخص نیست؛ قیمت هر گیگ محاسبه نشد", style = MaterialTheme.typography.bodySmall)
            }
            if (p.unlimited) {
                Text(
                    "نامحدود؛ قیمت هر گیگ بر اساس سقف مصرف منصفانه‌ی ذکرشده است",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
