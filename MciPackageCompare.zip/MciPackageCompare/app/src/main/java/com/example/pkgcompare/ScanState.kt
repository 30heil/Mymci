package com.example.pkgcompare

import kotlinx.coroutines.flow.MutableStateFlow

object ScanState {
    val packages = MutableStateFlow<List<TariffPackage>>(emptyList())
    val scanning = MutableStateFlow(false)
    val connected = MutableStateFlow(false)
    val status = MutableStateFlow("آماده")

    @Volatile
    var lastDump: String = ""

    /** بسته‌های جدید را اضافه می‌کند و تعداد موارد تازه را برمی‌گرداند */
    fun add(list: List<TariffPackage>): Int {
        val cur = packages.value
        val keys = cur.map { it.key }.toHashSet()
        val fresh = list.filter { it.key !in keys }.distinctBy { it.key }
        if (fresh.isNotEmpty()) packages.value = cur + fresh
        return fresh.size
    }

    fun clear() {
        packages.value = emptyList()
        status.value = "پاک شد"
    }
}
